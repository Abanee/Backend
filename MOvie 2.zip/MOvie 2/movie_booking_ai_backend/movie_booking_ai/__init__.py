"""
Movie Booking AI - Django Backend
"""
